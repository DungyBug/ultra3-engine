export interface IWorldProps {
    gravity: number;
    thinkPeriod: number;
}
