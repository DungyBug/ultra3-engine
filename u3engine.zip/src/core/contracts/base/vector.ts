export interface IVector {
    x: number;
    y: number;
    z: number;
}