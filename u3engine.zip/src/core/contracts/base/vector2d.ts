interface IVector2D {
    x: number;
    y: number;
}

export default IVector2D;