import { IVector } from "../base/vector";

export interface IForce {
    force: number;
    direction: IVector;
};