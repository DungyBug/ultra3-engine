export interface IDifficulty {
    easy: boolean;
    medium: boolean;
    hard: boolean;
}