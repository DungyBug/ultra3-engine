export enum TeleportType {
    in,
    out
}