enum PhysicalModelType {
    cube,
    sphere,
    cylinder,
    capsule
}

export default PhysicalModelType;