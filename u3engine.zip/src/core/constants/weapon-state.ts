export enum WeaponState {
    shooting,
    waitingForShoot,
    idle
};