export enum PlatformDirection {
    forward,
    backward
};