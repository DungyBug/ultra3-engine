export enum Side {
    top,
    bottom,
    left,
    right,
    back,
    forward
};