export enum DoorState {
    idling,
    opening,
    waiting,
    closing
}