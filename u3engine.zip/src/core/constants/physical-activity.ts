export enum PhysicalActivity {
    active,
    passive
};