export enum PlatformState {
    idling,
    moving
}