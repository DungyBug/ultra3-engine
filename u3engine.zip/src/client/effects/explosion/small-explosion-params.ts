import { IViewableEntityParams } from "../../contracts/entities/base/viewable";

export interface ISmallExplosionEntityParams extends IViewableEntityParams {
    classname: "effect_small_explosion";
}