enum SamplingMode {
    NEAREST,
    BILINEAR,
    TRILINEAR,
    BICUBIC
};

export default SamplingMode;