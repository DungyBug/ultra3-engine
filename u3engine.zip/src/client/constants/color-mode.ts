enum ColorMode {
    R,
    RG,
    RGB,
    RGBA,
    ALPHA,
    LUMINANCE,
    LUMINANCE_ALPHA
}

export default ColorMode;