enum ComplexShaderMixMode {
    MULTIPLY,
    SUBTRACT,
    ADD,
    CUSTOM
}

export default ComplexShaderMixMode;