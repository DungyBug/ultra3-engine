export enum ViewType {
    model,
    sprite,
    sprite_vertical // This kind of sprites rotates only in xz plane ( so if you look it from top to bottom you won't see them )
    // volume // Display cube with volume in it
};