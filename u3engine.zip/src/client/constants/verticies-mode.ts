enum VerticesMode {
    TRIANGLES,
    TRIANGLE_FAN,
    TRIANGLE_STRIP
}

export default VerticesMode;