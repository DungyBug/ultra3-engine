import AbstractTransporter from "../core/contracts/services/transporter/abstract-transporter";
import Transport from "../core/services/transport";
import IClientState from "../server/contracts/client-state";
import ClientWorld from "./client-world";

class Client extends ClientWorld {
    protected transport: Transport;
    private keys: Array<boolean> = new Array(113).fill(false);

    setState(state: IClientState) {
        super.setState(state);

        if (state.thisEntity !== -1) {
            const entity = state.entities[state.thisEntity];

            this.renderer.camera.position.x = entity.pos.x;
            this.renderer.camera.position.y = entity.pos.y;
            this.renderer.camera.position.z = entity.pos.z;
        }
    }

    start(transporter: AbstractTransporter) {
        this.transport = new Transport(transporter);

        this.runTick();
        this.renderer.runRenderLoop();
        document.addEventListener("keydown", this.handleKeyDown.bind(this));
        document.addEventListener("keyup", this.handleKeyUp.bind(this));
    }

    handleKeyDown(e: KeyboardEvent) {
        this.keys[e.keyCode] = true;
    }

    handleKeyUp(e: KeyboardEvent) {
        this.keys[e.keyCode] = false;
    }

    runTick() {
        super.runTick();

        if (this.keys[87]) {
            this.transport.send(
                JSON.stringify({
                    type: "update-player-state",
                    data: {
                        event: "move",
                        angle: this.renderer.camera.rotation.y,
                    },
                }),
                false
            );
        }
        if (this.keys[83]) {
            this.transport.send(
                JSON.stringify({
                    type: "update-player-state",
                    data: {
                        event: "move",
                        angle: this.renderer.camera.rotation.y + Math.PI,
                    },
                }),
                false
            );
        }
        if (this.keys[65]) {
            this.transport.send(
                JSON.stringify({
                    type: "update-player-state",
                    data: {
                        event: "move",
                        angle: this.renderer.camera.rotation.y - Math.PI * 0.5,
                    },
                }),
                false
            );
        }
        if (this.keys[68]) {
            this.transport.send(
                JSON.stringify({
                    type: "update-player-state",
                    data: {
                        event: "move",
                        angle: this.renderer.camera.rotation.y + Math.PI * 0.5,
                    },
                }),
                false
            );
        }

        this.transport
            .send(
                JSON.stringify({
                    type: "get-state",
                }),
                true
            )
            .then((data: string) => {
                const state = JSON.parse(data) as IClientState;

                this.setState(state);
            });
    }
}

export default Client;
