enum GLTFWrapMode {
    CLAMP_TO_EDGE=33071,
    MIRRORED_REPEAT=33648,
    REPEAT=10497
}

export default GLTFWrapMode;