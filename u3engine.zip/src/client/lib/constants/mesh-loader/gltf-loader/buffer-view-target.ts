enum GLTFBufferViewTarget {
    ARRAY_BUFFER=34962,
    ELEMENT_ARRAY_BUFFER=34963
}

export default GLTFBufferViewTarget;