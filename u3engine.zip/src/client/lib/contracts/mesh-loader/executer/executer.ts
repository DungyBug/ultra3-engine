import IExecuterInstance from "./instance";

interface IExecuter {
    execute(): void;
}

export default IExecuter;