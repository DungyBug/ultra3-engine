interface ICompilerOptions {
    entry: string;
    eventEntry: string;
    addCode?: string;
}

export default ICompilerOptions;