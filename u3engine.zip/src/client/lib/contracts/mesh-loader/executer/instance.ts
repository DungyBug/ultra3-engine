interface IExecuterInstance {
    environment: {
        [k: string]: any;
    }
    source: string;
}

export default IExecuterInstance;