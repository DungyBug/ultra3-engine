interface IGLTFBinary {
    name: string;
    data: ArrayBuffer;
}

export default IGLTFBinary;