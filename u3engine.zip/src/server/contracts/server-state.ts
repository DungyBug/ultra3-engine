import { IEntityState } from "../../core/contracts/entity";
import { IWorldState } from "../../core/contracts/world";

interface IServerState extends IWorldState {
    frame: number;
    date: number;
}

export default IServerState;
