interface IServerMessage {
    type: string;
    data?: unknown;
}

interface IUpdatePlayerState extends IServerMessage {
    type: "update-player-state";
    data: {
        event: string;
    };
}

interface IMovePlayer extends IUpdatePlayerState {
    data: {
        event: "move";
        angle: number;
    };
}

interface IGetState extends IServerMessage {
    type: "get-state";
    data?: never;
}

type ServerMessage = IMovePlayer | IGetState;

export default ServerMessage;
