import IServerState from "./server-state";

interface IClientState extends IServerState {
    thisEntity: number; // Link to ourself entity ( or -1 if ourself entity was not found )
}

export default IClientState;
