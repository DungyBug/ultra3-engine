export interface IWSSendOpts {
    data: string;
    to?: number;
}

export interface IWSSendToAllOpts {
    data: string;
}
