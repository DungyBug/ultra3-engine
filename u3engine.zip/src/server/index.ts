import * as http from "http";
import { Registry } from "../core/registry";
import Server from "./server";
import WSTransporter from "./services/transporter/ws-transporter";

const server = new Server(
    {
        gravity: 9.81,
        thinkPeriod: 100 / 6,
    },
    new Registry()
);

const httpServer = new http.Server();

httpServer.listen(3003);

server.start(new WSTransporter(httpServer));
