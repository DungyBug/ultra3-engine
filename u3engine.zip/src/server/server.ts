import AbstractTransporter, {
    ServerEvents,
} from "../core/contracts/services/transporter/abstract-transporter";
import { IWorldProps } from "../core/contracts/world-porps";
import { Player } from "../core/entities/player";
import { Registry } from "../core/registry";
import Transport from "../core/services/transport";
import { World } from "../core/world";
import IClientState from "./contracts/client-state";
import ServerMessage from "./contracts/message";
import IServerState from "./contracts/server-state";

class Server extends World {
    protected transport: Transport;
    private clients: Array<Player>;

    constructor(worldProps: IWorldProps, registry: Registry) {
        super(worldProps, registry);
        this.clients = [];
    }

    start(transporter: AbstractTransporter<ServerEvents>) {
        transporter.on("connection", this.handleConnection.bind(this));
        transporter.on("request", this.handleRequest.bind(this));
        transporter.on("disconnection", this.handleDisconnection.bind(this));
        this.transport = new Transport(transporter);
        this.transport.onMessage(this.handleMessage.bind(this));

        this.runTick();
    }

    getState(): IServerState {
        return {
            entities: [],
            mapobjects: [],
            frame: Math.floor((this._time / 1000) * 60),
            date: Date.now(),
            ...super.getState(),
        };
    }

    setState(state: IServerState) {
        super.setState(state);
    }

    private handleRequest(connectionID: number) {
        // Reject connection if previous player hasn't deleted yet
        if (this.clients[connectionID] !== undefined) {
            return false;
        }

        return true;
    }

    private handleConnection(connectionID: number) {
        this.clients[connectionID] = new Player(
            {
                classname: "player_player",
            },
            this
        );
    }

    private handleDisconnection(connectionID: number) {
        this.clients[connectionID].delete();
        this.clients[connectionID] = undefined;
    }

    private handleMessage(
        message: string,
        res: (message: string) => void,
        from: number
    ) {
        const req = JSON.parse(message) as ServerMessage;

        switch (req.type) {
            case "get-state": {
                const state: IClientState = {
                    thisEntity: -1,
                    ...this.getState(),
                };

                if (this.clients[from] !== undefined) {
                    state.thisEntity = this.entities.indexOf(
                        this.clients[from]
                    );
                }

                res(JSON.stringify(state));

                break;
            }
            case "update-player-state": {
                switch (req.data.event) {
                    case "move": {
                        const x = Math.sin(req.data.angle) * 0.1;
                        const z = Math.cos(req.data.angle) * 0.1;

                        // Also check, if this client exists and not in deleting state
                        this.clients[from].pos.x += x;
                        this.clients[from].pos.z += z;

                        res(
                            JSON.stringify({
                                state: "success",
                            })
                        );
                        break;
                    }

                    default: {
                        res(
                            JSON.stringify({
                                error: "Unknown event",
                            })
                        );
                        break;
                    }
                }

                break;
            }

            default: {
                res(
                    JSON.stringify({
                        error: "Unknown type",
                    })
                );
                break;
            }
        }
    }
}

export default Server;
