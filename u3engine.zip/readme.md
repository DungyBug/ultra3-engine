# Ultra3 engine
#### Engine for non-eucledian geometry games.

Graphics made up with Babylon.JS

## Features:
### Mesh loaders
Supported formats:

- GLTF/GLB
### Shaders
- Volumetric shader
- Bicubic texture filtering